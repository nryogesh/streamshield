let accessLog = [];
let accessCount = 0;
let threatCount = 0;

function updateUI(streamMode) {
  const dot = document.getElementById('statusDot');
  const label = document.getElementById('statusLabel');
  const toggle = document.getElementById('mainToggle');

  toggle.checked = streamMode;

  if (streamMode) {
    dot.classList.add('active');
    label.classList.add('active');
    label.textContent = 'STREAM SAFE';
  } else {
    dot.classList.remove('active');
    label.classList.remove('active');
    label.textContent = 'OFFLINE';
  }
}

function renderLog() {
  const list = document.getElementById('logList');
  if (!accessLog.length) {
    list.innerHTML = '<div class="log-empty">No activity yet</div>';
    return;
  }
  list.innerHTML = accessLog.slice(0, 6).map(e => `
    <div class="log-entry">
      <span class="log-time">${e.time}</span>
      <span class="log-label">${e.label}</span>
    </div>
  `).join('');
}

chrome.storage.local.get(['streamMode', 'accessLog', 'shieldCount', 'accessCount', 'threatCount'], (result) => {
  updateUI(result.streamMode || false);
  accessLog = result.accessLog || [];
  accessCount = result.accessCount || 0;
  threatCount = result.threatCount || 0;

  document.getElementById('shieldCount').textContent = result.shieldCount || 0;
  document.getElementById('accessCount').textContent = accessCount;
  document.getElementById('threatCount').textContent = threatCount;
  renderLog();
});

document.getElementById('mainToggle').addEventListener('change', (e) => {
  const enabled = e.target.checked;
  chrome.runtime.sendMessage({ type: 'SET_STREAM_MODE', enabled }, () => {
    updateUI(enabled);
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { type: 'TOGGLE_STREAM_MODE', enabled }).catch(() => {});
      }
    });
  });
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'ACCESS_LOG') {
    accessLog.unshift(message.entry);
    if (accessLog.length > 20) accessLog.pop();
    accessCount++;
    document.getElementById('accessCount').textContent = accessCount;
    renderLog();
    chrome.storage.local.set({ accessLog, accessCount });
  }
});
