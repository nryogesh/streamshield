# StreamShield — Chrome Extension

## What It Does
StreamShield automatically detects and encrypts sensitive credentials on any webpage.
Hover to decrypt. One keystroke to go stream-safe.

## Install in Chrome (30 seconds)
1. Open Chrome → go to `chrome://extensions`
2. Enable **Developer Mode** (top right toggle)
3. Click **Load unpacked**
4. Select the `streamshield` folder
5. Pin the extension to your toolbar

## Demo
1. Open `demo.html` in Chrome after installing
2. Click the StreamShield icon → toggle Stream Mode ON
3. Watch all credentials encrypt instantly
4. Hover any field to decrypt with character shuffle
5. Try moving mouse fast — triggers danger mode
6. Rapid hover across fields — triggers lockdown

## Keyboard Shortcut
`Ctrl+Shift+S` — toggle stream mode on any page

## What Gets Detected
- AWS Access Keys & Secrets (CRITICAL)
- GitHub Personal Access Tokens (CRITICAL)
- Generic API Keys — sk-, pk-, api_ prefixes (HIGH)
- JWT Tokens (HIGH)
- Database URLs — postgresql, mongodb, redis (HIGH)
- Private Keys / PEM certificates (CRITICAL)
- Environment variables with sensitive names (HIGH)

## Creative Features
- Format-aware gibberish — API keys look like encrypted API keys
- Living encryption — gibberish mutates subtly when idle
- Freeze effect — half-second pause before decrypt fires
- Speed detection — fast mouse movement triggers danger flash
- Anomaly lockdown — rapid suspicious hovers lock all fields
- Ghost timestamps — access time fades in after reveal
- Auto re-encrypt — fields re-encrypt after 8 seconds of inactivity
- Access log — every reveal is logged in the HUD panel
