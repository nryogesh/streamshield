chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ streamMode: false });
});

chrome.commands && chrome.commands.onCommand && chrome.commands.onCommand.addListener((command) => {
  if (command === 'toggle-stream-mode') {
    chrome.storage.local.get(['streamMode'], (result) => {
      const newMode = !result.streamMode;
      chrome.storage.local.set({ streamMode: newMode });
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, { 
            type: 'TOGGLE_STREAM_MODE', 
            enabled: newMode 
          });
        }
      });
    });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_STREAM_MODE') {
    chrome.storage.local.get(['streamMode'], (result) => {
      sendResponse({ streamMode: result.streamMode || false });
    });
    return true;
  }
  if (message.type === 'SET_STREAM_MODE') {
    chrome.storage.local.set({ streamMode: message.enabled });
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, { 
          type: 'TOGGLE_STREAM_MODE', 
          enabled: message.enabled 
        }).catch(() => {});
      });
    });
    sendResponse({ ok: true });
    return true;
  }
});
