(() => {
  // ─── PATTERN DETECTION ENGINE ───────────────────────────────────────────────
  const PATTERNS = [
    {
      type: 'aws_key',
      label: 'AWS Access Key',
      regex: /\b(AKIA|ASIA|AROA|AIDA)[A-Z0-9]{16}\b/g,
      gibberishStyle: 'aws',
      severity: 'critical'
    },
    {
      type: 'aws_secret',
      label: 'AWS Secret',
      regex: /\b[A-Za-z0-9/+=]{40}\b/g,
      gibberishStyle: 'base64',
      severity: 'critical'
    },
    {
      type: 'github_token',
      label: 'GitHub Token',
      regex: /\b(ghp_|gho_|ghu_|ghs_|ghr_)[A-Za-z0-9]{36,}\b/g,
      gibberishStyle: 'github',
      severity: 'critical'
    },
    {
      type: 'generic_api_key',
      label: 'API Key',
      regex: /\b(sk-|pk-|api_|key_|token_)[A-Za-z0-9_\-]{20,}\b/gi,
      gibberishStyle: 'apikey',
      severity: 'high'
    },
    {
      type: 'jwt',
      label: 'JWT Token',
      regex: /\beyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\b/g,
      gibberishStyle: 'jwt',
      severity: 'high'
    },
    {
      type: 'db_url',
      label: 'Database URL',
      regex: /\b(mongodb(\+srv)?|postgresql|mysql|redis):\/\/[^\s"'<>]+/gi,
      gibberishStyle: 'dburl',
      severity: 'high'
    },
    {
      type: 'private_key',
      label: 'Private Key',
      regex: /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g,
      gibberishStyle: 'pem',
      severity: 'critical'
    },
    {
      type: 'netlify_token',
      label: 'Netlify Token',
      regex: /\b[a-f0-9]{40,}\b/g,
      gibberishStyle: 'hex',
      severity: 'high'
    },
    {
      type: 'env_variable',
      label: 'Env Variable',
      regex: /\b[A-Z_]{3,}_(KEY|SECRET|TOKEN|PASSWORD|PASS|PWD|APIKEY|API_KEY)\s*=\s*["']?([^\s"']+)["']?/g,
      gibberishStyle: 'apikey',
      severity: 'high'
    },
    // Supabase anon/service keys (long JWT structure)
    {
      type: 'supabase_key',
      label: 'Supabase Key',
      regex: /\beyJ[A-Za-z0-9_\-]{50,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\b/g,
      gibberishStyle: 'jwt',
      severity: 'critical'
    }
  ];

  // Env variable name pattern — used for split-element detection (FIX 4)
  const ENV_KEY_PATTERN = /^[A-Z_]{3,}_(KEY|SECRET|TOKEN|PASSWORD|PASS|PWD|APIKEY|API_KEY)$/;

  // ─── GIBBERISH GENERATORS ────────────────────────────────────────────────────
  const CHARS = {
    base64: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=',
    hex: '0123456789abcdef',
    upper: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
    symbol: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*',
    alphanum: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-'
  };

  function rand(str) { return str[Math.floor(Math.random() * str.length)]; }
  function randStr(chars, len) { return Array.from({length: len}, () => rand(chars)).join(''); }

  function generateGibberish(original, style) {
    const len = original.length;
    switch(style) {
      case 'aws':
        return 'AKIA' + randStr(CHARS.upper, len - 4);
      case 'github': {
        const prefix = original.substring(0, 4);
        return prefix + randStr(CHARS.alphanum, len - 4);
      }
      case 'jwt': {
        const parts = original.split('.');
        return parts.map(p => randStr(CHARS.base64, p.length)).join('.');
      }
      case 'dburl': {
        const proto = original.match(/^[a-z+]+:\/\//i)?.[0] || 'postgresql://';
        return proto + randStr(CHARS.alphanum, 8) + ':' + randStr(CHARS.base64, 16) + '@' + randStr(CHARS.alphanum, 10) + '.db.example.com/prod';
      }
      case 'pem':
        return `-----BEGIN ENCRYPTED PRIVATE KEY-----\n${randStr(CHARS.base64, 64)}\n${randStr(CHARS.base64, 64)}\n-----END ENCRYPTED PRIVATE KEY-----`;
      case 'hex':
        return randStr(CHARS.hex, len);
      case 'base64':
        return randStr(CHARS.base64, len);
      case 'apikey':
      default:
        return randStr(CHARS.symbol, len);
    }
  }

  // ─── STATE ──────────────────────────────────────────────────────────────────
  let streamMode = false;
  let shieldedElements = new Map();
  let shieldedInputs = new Map();     // FIX 1: track shielded inputs
  let accessLog = [];
  let suspiciousHoverCount = 0;
  let lastHoverTime = 0;
  let isLockedDown = false;
  let observer = null;
  let shadowObservers = [];            // FIX 2: track shadow DOM observers

  // ─── SEVERITY COLORS ────────────────────────────────────────────────────────
  const SEVERITY_COLORS = {
    critical: { border: '#ff4444', glow: 'rgba(255,68,68,0.15)', badge: '#ff4444', text: '#fff' },
    high:     { border: '#ff8800', glow: 'rgba(255,136,0,0.12)', badge: '#ff8800', text: '#fff' },
    medium:   { border: '#ffcc00', glow: 'rgba(255,204,0,0.10)', badge: '#ffcc00', text: '#000' }
  };

  // ─── BREATHING ANIMATION ────────────────────────────────────────────────────
  function startBreathing(wrapper, gibberishSpan, original, style) {
    if (wrapper._breatheTimer) clearInterval(wrapper._breatheTimer);
    wrapper._breatheTimer = setInterval(() => {
      if (!streamMode || wrapper._hovered || isLockedDown) return;
      const current = gibberishSpan.textContent;
      const mutated = current.split('').map(c => {
        if (c === ' ' || c === '\n' || c === '.' || c === ':' || c === '/') return c;
        return Math.random() < 0.08 ? rand(CHARS.symbol) : c;
      }).join('');
      gibberishSpan.textContent = mutated;
    }, 150);
  }

  // ─── DECRYPT ANIMATION ──────────────────────────────────────────────────────
  function animateDecrypt(el, target, duration, onDone) {
    const steps = Math.ceil(duration / 30);
    let step = 0;
    if (el._decryptTimer) clearInterval(el._decryptTimer);
    el._decryptTimer = setInterval(() => {
      step++;
      const progress = step / steps;
      const revealed = Math.floor(progress * target.length);
      let result = '';
      for (let i = 0; i < target.length; i++) {
        if (i < revealed) result += target[i];
        else if ([' ', '\n', '.', ':', '/'].includes(target[i])) result += target[i];
        else result += rand(CHARS.symbol);
      }
      el.textContent = result;
      if (step >= steps) {
        clearInterval(el._decryptTimer);
        el.textContent = target;
        if (onDone) onDone();
      }
    }, 30);
  }

  // ─── ENCRYPT ANIMATION ──────────────────────────────────────────────────────
  function animateEncrypt(el, original, style, duration) {
    const gibberish = generateGibberish(original, style);
    const steps = Math.ceil(duration / 25);
    let step = 0;
    if (el._encryptTimer) clearInterval(el._encryptTimer);
    el._encryptTimer = setInterval(() => {
      step++;
      const progress = step / steps;
      const encryptedCount = Math.floor(progress * original.length);
      let result = '';
      for (let i = 0; i < original.length; i++) {
        if (i < encryptedCount) result += [' ', '\n', '.', ':', '/'].includes(original[i]) ? original[i] : rand(CHARS.symbol);
        else result += original[i];
      }
      el.textContent = result;
      if (step >= steps) {
        clearInterval(el._encryptTimer);
        el.textContent = gibberish;
      }
    }, 25);
  }

  // ─── ACCESS LOG ─────────────────────────────────────────────────────────────
  function logAccess(type, label) {
    const entry = { type, label, time: new Date().toLocaleTimeString(), ts: Date.now() };
    accessLog.unshift(entry);
    if (accessLog.length > 20) accessLog.pop();
    updateAccessLogPanel();
    chrome.runtime.sendMessage({ type: 'ACCESS_LOG', entry }).catch(() => {});
  }

  function updateAccessLogPanel() {
    const panel = document.getElementById('ss-access-log');
    if (!panel) return;
    const list = panel.querySelector('.ss-log-list');
    if (!list) return;
    list.innerHTML = accessLog.slice(0, 8).map(e => `
      <div class="ss-log-entry">
        <span class="ss-log-time">${e.time}</span>
        <span class="ss-log-label">${e.label}</span>
      </div>
    `).join('');
  }

  // ─── LOCKDOWN ───────────────────────────────────────────────────────────────
  function triggerLockdown() {
    if (isLockedDown) return;
    isLockedDown = true;

    shieldedElements.forEach(({ wrapper, gibberishSpan, original, style }) => {
      if (wrapper._hovered) {
        animateEncrypt(gibberishSpan, original, style, 200);
        wrapper._hovered = false;
      }
      const colors = SEVERITY_COLORS['critical'];
      wrapper.style.borderColor = colors.border;
      wrapper.style.boxShadow = `0 0 12px ${colors.glow}`;
    });

    // FIX 1: lockdown inputs too
    shieldedInputs.forEach(({ input, gibberish, pattern }) => {
      const colors = SEVERITY_COLORS['critical'];
      input.value = gibberish;
      input.style.outline = `2px solid ${colors.border}`;
      input.style.boxShadow = `0 0 12px ${colors.glow}`;
    });

    showLockdownBanner();
    setTimeout(() => {
      isLockedDown = false;
      suspiciousHoverCount = 0;
      hideLockdownBanner();
      shieldedElements.forEach(({ wrapper, pattern }) => {
        const colors = SEVERITY_COLORS[pattern.severity] || SEVERITY_COLORS['high'];
        wrapper.style.borderColor = colors.border;
        wrapper.style.boxShadow = `0 0 8px ${colors.glow}`;
      });
    }, 4000);
  }

  function showLockdownBanner() {
    let banner = document.getElementById('ss-lockdown-banner');
    if (!banner) {
      banner = document.createElement('div');
      banner.id = 'ss-lockdown-banner';
      banner.innerHTML = `
        <div class="ss-lockdown-icon">⚠</div>
        <div class="ss-lockdown-text">
          <strong>ANOMALOUS ACCESS PATTERN DETECTED</strong>
          <span>All fields secured — StreamShield lockdown active</span>
        </div>
      `;
      document.body.appendChild(banner);
    }
    banner.classList.add('ss-visible');
  }

  function hideLockdownBanner() {
    const banner = document.getElementById('ss-lockdown-banner');
    if (banner) banner.classList.remove('ss-visible');
  }

  // ─── GHOST TIMESTAMP ────────────────────────────────────────────────────────
  function showGhostTimestamp(wrapper) {
    let ghost = wrapper.querySelector('.ss-ghost-time');
    if (!ghost) {
      ghost = document.createElement('span');
      ghost.className = 'ss-ghost-time';
      wrapper.appendChild(ghost);
    }
    ghost.textContent = `accessed ${new Date().toLocaleTimeString()}`;
    ghost.classList.add('ss-ghost-visible');
    setTimeout(() => ghost.classList.remove('ss-ghost-visible'), 3000);
  }

  // ─── AUTO RE-ENCRYPT TIMER ──────────────────────────────────────────────────
  function startAutoReencrypt(wrapper, gibberishSpan, original, style) {
    if (wrapper._autoTimer) clearTimeout(wrapper._autoTimer);
    wrapper._autoTimer = setTimeout(() => {
      if (wrapper._hovered) return;
      animateEncrypt(gibberishSpan, original, style, 400);
      const badge = wrapper.querySelector('.ss-auto-badge');
      if (badge) {
        badge.textContent = 'AUTO-SECURED';
        badge.style.background = '#ff4444';
        setTimeout(() => {
          badge.textContent = wrapper._pattern?.label || 'SECURED';
          badge.style.background = '';
        }, 2000);
      }
    }, 8000);
  }

  // ─── WRAP SENSITIVE TEXT NODE ─────────────────────────────────────────────────
  function wrapSensitiveText(node, match, pattern) {
    const original = match;
    const gibberish = generateGibberish(original, pattern.gibberishStyle);
    const colors = SEVERITY_COLORS[pattern.severity] || SEVERITY_COLORS['high'];

    const wrapper = document.createElement('span');
    wrapper.className = `ss-shield ss-shield-${pattern.severity}`;
    wrapper.dataset.ssId = Math.random().toString(36).slice(2);
    wrapper._hovered = false;
    wrapper._pattern = pattern;

    const gibberishSpan = document.createElement('span');
    gibberishSpan.className = 'ss-gibberish';
    gibberishSpan.textContent = gibberish;

    const badge = document.createElement('span');
    badge.className = 'ss-badge';
    badge.textContent = pattern.label;
    badge.style.background = colors.badge;
    badge.style.color = colors.text;

    wrapper.appendChild(gibberishSpan);
    wrapper.appendChild(badge);
    wrapper.style.borderColor = colors.border;
    wrapper.style.boxShadow = `0 0 8px ${colors.glow}`;

    wrapper.addEventListener('mouseenter', (e) => {
      if (isLockedDown) return;
      const now = Date.now();
      if (now - lastHoverTime < 300) {
        suspiciousHoverCount++;
        if (suspiciousHoverCount >= 4) { triggerLockdown(); return; }
      } else {
        suspiciousHoverCount = 0;
      }
      lastHoverTime = now;

      const speed = Math.abs(e.movementX) + Math.abs(e.movementY);
      if (speed > 40) {
        wrapper.classList.add('ss-fast-hover');
        setTimeout(() => wrapper.classList.remove('ss-fast-hover'), 600);
        return;
      }

      wrapper._hovered = true;
      if (wrapper._breatheTimer) clearInterval(wrapper._breatheTimer);
      if (wrapper._autoTimer) clearTimeout(wrapper._autoTimer);
      wrapper.classList.add('ss-freeze');
      setTimeout(() => {
        wrapper.classList.remove('ss-freeze');
        const duration = pattern.severity === 'critical' ? 600 : pattern.severity === 'high' ? 450 : 300;
        animateDecrypt(gibberishSpan, original, duration, () => {
          showGhostTimestamp(wrapper);
          logAccess(pattern.type, pattern.label);
          startAutoReencrypt(wrapper, gibberishSpan, original, pattern.gibberishStyle);
        });
      }, 500);
    });

    wrapper.addEventListener('mouseleave', () => {
      if (!wrapper._hovered) return;
      wrapper._hovered = false;
      if (wrapper._autoTimer) clearTimeout(wrapper._autoTimer);
      animateEncrypt(gibberishSpan, original, pattern.gibberishStyle, 350);
      startBreathing(wrapper, gibberishSpan, original, pattern.gibberishStyle);
    });

    shieldedElements.set(wrapper.dataset.ssId, {
      wrapper, gibberishSpan, original,
      style: pattern.gibberishStyle, pattern
    });

    startBreathing(wrapper, gibberishSpan, original, pattern.gibberishStyle);
    return wrapper;
  }

  // ─── FIX 1: SHIELD INPUT / TEXTAREA ELEMENTS ────────────────────────────────
  // GitHub PAT pages and Supabase show secrets inside <input value="...">.
  // TreeWalker only sees text nodes — it never reads .value. Fixed here.

  function detectPatternInValue(value) {
    for (const pattern of PATTERNS) {
      pattern.regex.lastIndex = 0;
      if (pattern.regex.test(value)) return pattern;
    }
    return null;
  }

  function shieldInput(input, pattern) {
    if (input._ssShielded) return;
    input._ssShielded = true;

    const original = input.value;
    const id = Math.random().toString(36).slice(2);
    const colors = SEVERITY_COLORS[pattern.severity] || SEVERITY_COLORS['high'];
    const gibberish = generateGibberish(original, pattern.gibberishStyle);

    input.value = gibberish;
    input.dataset.ssId = id;
    input.style.outline = `2px solid ${colors.border}`;
    input.style.boxShadow = `0 0 8px ${colors.glow}`;
    input.readOnly = true;

    // Badge overlay
    const wrapperEl = document.createElement('span');
    wrapperEl.className = 'ss-input-wrapper';
    wrapperEl.style.cssText = 'position:relative;display:inline-block;width:100%;';

    const badge = document.createElement('span');
    badge.className = 'ss-badge ss-input-badge';
    badge.textContent = pattern.label;
    badge.style.background = colors.badge;
    badge.style.color = colors.text;

    if (input.parentNode) {
      input.parentNode.insertBefore(wrapperEl, input);
      wrapperEl.appendChild(input);
      wrapperEl.appendChild(badge);
    }

    input.addEventListener('mouseenter', () => {
      if (isLockedDown) return;
      const now = Date.now();
      if (now - lastHoverTime < 300) {
        suspiciousHoverCount++;
        if (suspiciousHoverCount >= 4) { triggerLockdown(); return; }
      } else { suspiciousHoverCount = 0; }
      lastHoverTime = now;

      input._ssHovered = true;
      input.value = original;
      input.style.outline = `2px solid #00ff88`;
      logAccess(pattern.type, pattern.label);

      if (input._autoTimer) clearTimeout(input._autoTimer);
      input._autoTimer = setTimeout(() => {
        if (!input._ssHovered) {
          input.value = gibberish;
          input.style.outline = `2px solid ${colors.border}`;
        }
      }, 8000);
    });

    input.addEventListener('mouseleave', () => {
      input._ssHovered = false;
      if (input._autoTimer) clearTimeout(input._autoTimer);
      input.value = gibberish;
      input.style.outline = `2px solid ${colors.border}`;
    });

    shieldedInputs.set(id, { input, original, pattern, gibberish, wrapper: wrapperEl });
  }

  function unshieldInput(id) {
    const data = shieldedInputs.get(id);
    if (!data) return;
    const { input, original, wrapper } = data;
    if (input._autoTimer) clearTimeout(input._autoTimer);
    input.value = original;
    input.style.outline = '';
    input.style.boxShadow = '';
    input.readOnly = false;
    input._ssShielded = false;
    delete input.dataset.ssId;
    if (wrapper && wrapper.parentNode) {
      wrapper.parentNode.insertBefore(input, wrapper);
      wrapper.remove();
    }
    shieldedInputs.delete(id);
  }

  function scanInputs(root) {
    const sel = 'input[type="text"], input[type="password"], input:not([type]), textarea, [data-value]';
    const inputs = (root || document).querySelectorAll(sel);
    inputs.forEach(input => {
      if (input._ssShielded) return;
      if (input.closest('#ss-panel, #ss-lockdown-banner')) return;
      const val = input.value || input.dataset.value || '';
      if (!val || val.length < 15) return;
      const pattern = detectPatternInValue(val);
      if (pattern) shieldInput(input, pattern);
    });
  }

  // ─── FIX 4: SPLIT-ELEMENT KEY=VALUE DETECTION ────────────────────────────────
  // GitHub/Supabase put the env key name and its value in separate sibling elements.
  // The original env_variable regex expects them in a single text node — it never matches.
  // We look for leaf elements whose text is a known env key name, then check nearby siblings.

  function scanSplitKeyValues(root) {
    const all = (root || document).querySelectorAll('*');
    all.forEach(el => {
      if (el._ssSplitChecked) return;
      if (el.closest('.ss-shield, #ss-panel, #ss-lockdown-banner')) return;
      if (el.children.length > 0) return; // leaf only
      const text = (el.textContent || '').trim();
      if (!ENV_KEY_PATTERN.test(text)) return;

      el._ssSplitChecked = true;

      const candidates = [];
      if (el.nextElementSibling) candidates.push(el.nextElementSibling);
      if (el.parentElement?.nextElementSibling) candidates.push(el.parentElement.nextElementSibling);

      // Table row: next td
      const row = el.closest('tr');
      if (row) {
        const tds = Array.from(row.querySelectorAll('td, th'));
        const idx = tds.findIndex(td => td.contains(el));
        if (idx >= 0 && tds[idx + 1]) candidates.push(tds[idx + 1]);
      }

      // dt/dd pairs
      const dt = el.tagName === 'DT' ? el : el.closest('dt');
      if (dt?.nextElementSibling?.tagName === 'DD') candidates.push(dt.nextElementSibling);

      candidates.forEach(candidate => {
        if (!candidate || candidate._ssScannedSplit) return;
        candidate._ssScannedSplit = true;
        const valText = (candidate.textContent || '').trim();
        if (!valText || valText.length < 15) return;
        const pattern = detectPatternInValue(valText);
        if (!pattern) return;

        // Find and wrap the actual text node inside the candidate
        const tw = document.createTreeWalker(candidate, NodeFilter.SHOW_TEXT);
        let n;
        while ((n = tw.nextNode())) {
          const t = n.textContent.trim();
          if (t.length < 15) continue;
          pattern.regex.lastIndex = 0;
          if (pattern.regex.test(t)) {
            const span = document.createElement('span');
            n.parentNode.insertBefore(span, n);
            span.appendChild(n);
            span.replaceWith(wrapSensitiveText(n, t, pattern));
            break;
          }
        }
      });
    });
  }

  // ─── SCAN & SHIELD PAGE ─────────────────────────────────────────────────────
  function shieldPage(root) {
    if (!streamMode) return;
    const scanRoot = root || document.body;

    const walker = document.createTreeWalker(
      scanRoot,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const parent = node.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          if (parent.closest('.ss-shield, #ss-panel, #ss-lockdown-banner, #ss-access-log, script, style, noscript')) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    const toReplace = [];
    let node;
    while ((node = walker.nextNode())) {
      const text = node.textContent;
      for (const pattern of PATTERNS) {
        pattern.regex.lastIndex = 0;
        if (pattern.regex.test(text)) {
          toReplace.push({ node, pattern, text });
          break;
        }
      }
    }

    toReplace.forEach(({ node, pattern, text }) => {
      pattern.regex.lastIndex = 0;
      const matches = [...text.matchAll(new RegExp(pattern.regex.source, pattern.regex.flags))];
      if (!matches.length) return;

      const frag = document.createDocumentFragment();
      let lastIndex = 0;

      matches.forEach(match => {
        if (match.index > lastIndex) {
          frag.appendChild(document.createTextNode(text.slice(lastIndex, match.index)));
        }
        frag.appendChild(wrapSensitiveText(node, match[0], pattern));
        lastIndex = match.index + match[0].length;
      });

      if (lastIndex < text.length) {
        frag.appendChild(document.createTextNode(text.slice(lastIndex)));
      }

      node.parentNode.replaceChild(frag, node);
    });

    scanInputs(scanRoot);           // FIX 1
    scanSplitKeyValues(scanRoot);   // FIX 4
    scanShadowRoots(scanRoot);      // FIX 2

    updateShieldCount();
  }

  // ─── FIX 2: SHADOW DOM SCANNING ──────────────────────────────────────────────
  // Supabase uses shadow DOM (web components / React portals). The TreeWalker
  // cannot cross shadow boundaries. We recurse into each shadowRoot we find.

  function scanShadowRoots(root) {
    const all = (root || document).querySelectorAll('*');
    all.forEach(el => {
      if (!el.shadowRoot || el._ssShadowObserved) return;
      el._ssShadowObserved = true;

      shieldPage(el.shadowRoot);

      const shadowObs = new MutationObserver((mutations) => {
        let needsScan = false;
        mutations.forEach(m => {
          if (m.type === 'characterData') needsScan = true;
          m.addedNodes.forEach(n => {
            if (n.nodeType === 1 || (n.nodeType === 3 && n.textContent.trim().length > 10)) needsScan = true;
          });
        });
        if (needsScan) setTimeout(() => shieldPage(el.shadowRoot), 500);
      });

      shadowObs.observe(el.shadowRoot, {
        childList: true,
        subtree: true,
        characterData: true   // FIX 3
      });
      shadowObservers.push(shadowObs);
    });
  }

  // ─── UNSHIELD PAGE ──────────────────────────────────────────────────────────
  function unshieldPage() {
    document.querySelectorAll('.ss-shield').forEach(wrapper => {
      const id = wrapper.dataset.ssId;
      const data = shieldedElements.get(id);
      if (data) {
        if (wrapper._breatheTimer) clearInterval(wrapper._breatheTimer);
        if (wrapper._autoTimer) clearTimeout(wrapper._autoTimer);
        wrapper.replaceWith(document.createTextNode(data.original));
        shieldedElements.delete(id);
      }
    });
    [...shieldedInputs.keys()].forEach(id => unshieldInput(id));  // FIX 1
    shadowObservers.forEach(o => o.disconnect());                   // FIX 2
    shadowObservers = [];
    updateShieldCount();
  }

  function updateShieldCount() {
    const total = shieldedElements.size + shieldedInputs.size;
    const countEl = document.getElementById('ss-shield-count');
    if (countEl) countEl.textContent = total;
    const badge = document.getElementById('ss-ext-badge');
    if (badge) badge.textContent = total || '';
  }

  // ─── HUD PANEL ──────────────────────────────────────────────────────────────
  function createHUD() {
    if (document.getElementById('ss-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'ss-panel';
    panel.innerHTML = `
      <div class="ss-panel-header">
        <div class="ss-panel-logo">
          <span class="ss-logo-icon">⬡</span>
          <span class="ss-logo-text">StreamShield</span>
        </div>
        <div class="ss-panel-controls">
          <button id="ss-minimize" title="Minimize">−</button>
        </div>
      </div>
      <div class="ss-panel-body" id="ss-panel-body">
        <div class="ss-status-row">
          <div class="ss-status-dot" id="ss-status-dot"></div>
          <span class="ss-status-text" id="ss-status-text">OFFLINE</span>
        </div>
        <div class="ss-toggle-row">
          <label class="ss-toggle-label">Stream Mode</label>
          <label class="ss-switch">
            <input type="checkbox" id="ss-toggle">
            <span class="ss-slider"></span>
          </label>
        </div>
        <div class="ss-stat-row">
          <div class="ss-stat">
            <span class="ss-stat-val" id="ss-shield-count">0</span>
            <span class="ss-stat-label">shielded</span>
          </div>
          <div class="ss-stat">
            <span class="ss-stat-val" id="ss-log-count">0</span>
            <span class="ss-stat-label">accessed</span>
          </div>
        </div>
        <div id="ss-access-log">
          <div class="ss-log-title">ACCESS LOG</div>
          <div class="ss-log-list"></div>
        </div>
        <div class="ss-shortcut">Ctrl+Shift+S to toggle</div>
      </div>
    `;
    document.body.appendChild(panel);

    const toggle = document.getElementById('ss-toggle');
    toggle.checked = streamMode;
    toggle.addEventListener('change', () => toggleStreamMode(toggle.checked));

    document.getElementById('ss-minimize').addEventListener('click', () => {
      const body = document.getElementById('ss-panel-body');
      body.classList.toggle('ss-hidden');
      document.getElementById('ss-minimize').textContent = body.classList.contains('ss-hidden') ? '+' : '−';
    });

    updateHUDStatus();
  }

  function updateHUDStatus() {
    const dot = document.getElementById('ss-status-dot');
    const text = document.getElementById('ss-status-text');
    const toggle = document.getElementById('ss-toggle');
    if (!dot || !text) return;
    if (streamMode) {
      dot.style.background = '#00ff88';
      dot.style.boxShadow = '0 0 6px #00ff88';
      text.textContent = 'STREAM SAFE';
      text.style.color = '#00ff88';
    } else {
      dot.style.background = '#666';
      dot.style.boxShadow = 'none';
      text.textContent = 'OFFLINE';
      text.style.color = '#666';
    }
    if (toggle) toggle.checked = streamMode;
  }

  // ─── TOGGLE STREAM MODE ─────────────────────────────────────────────────────
  function toggleStreamMode(enable) {
    streamMode = enable;
    chrome.runtime.sendMessage({ type: 'SET_STREAM_MODE', enabled: enable }).catch(() => {});

    if (enable) {
      shieldPage();
      startMutationObserver();
    } else {
      unshieldPage();
      if (observer) { observer.disconnect(); observer = null; }
      hideLockdownBanner();
      isLockedDown = false;
      suspiciousHoverCount = 0;
    }
    updateHUDStatus();
  }

  // ─── FIX 3: IMPROVED MUTATION OBSERVER ──────────────────────────────────────
  // Old: only childList, 300ms debounce.
  // New: also watches characterData, debounce bumped to 500ms,
  //      properly debounces rapid SPA batch updates, catches raw text node additions.

  function startMutationObserver() {
    if (observer) observer.disconnect();
    let debounceTimer = null;
    observer = new MutationObserver((mutations) => {
      let needsScan = false;
      mutations.forEach(m => {
        if (m.type === 'characterData') needsScan = true;
        m.addedNodes.forEach(n => {
          if (n.nodeType === 1 && !n.closest('.ss-shield, #ss-panel')) needsScan = true;
          if (n.nodeType === 3 && n.textContent.trim().length > 10) needsScan = true;
        });
      });
      if (needsScan) {
        if (debounceTimer) clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => shieldPage(), 500);
      }
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true   // FIX 3: catch text mutations
    });
  }

  // ─── KEYBOARD SHORTCUT ──────────────────────────────────────────────────────
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.shiftKey && e.key === 'S') {
      e.preventDefault();
      toggleStreamMode(!streamMode);
    }
  });

  // ─── MESSAGE LISTENER ───────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'TOGGLE_STREAM_MODE') {
      toggleStreamMode(message.enabled);
    }
  });

  // ─── INIT ────────────────────────────────────────────────────────────────────
  chrome.runtime.sendMessage({ type: 'GET_STREAM_MODE' }, (response) => {
    streamMode = response?.streamMode || false;
    createHUD();
    if (streamMode) {
      shieldPage();
      startMutationObserver();
    }
  });

})();
